set head off feed off
alter profile default limit password_verify_function null;
exit
